(function(){
  var body = document.body;
  (function(){
    var div = document.createElement('div');
    body.appendChild(div);
  })();

})();
